<div id="content">

    <section>

        <div class="container">
            <div class="row">
                <?=$page->content?>
            </div>
        </div>
</div>

</section>

</div>