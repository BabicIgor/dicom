<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Pages
 * @author Admin
 * @property Page_model $page_model
 * @property Aauth $aauth
 */
class Signup extends Public_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('signup/user_model');
        $this->load->library('functions');
		$this->load->library('session');
        
    }
	public function index()
	{
	    $request = json_decode(file_get_contents('php://input'));
        $email = $request->email;
        $password = $request->password;
        $name = $request->name;
		$res = $this->user_model->add_new_user($name, $email, $password);
		if($res > 0)
		{
        	$login_data = array(
        		'login_result' => 1,
        		'userName'=>$res->username,
        		'userid'=>$res->id
        	);
		    $this->session->set_userdata($login_data);
		}
		$result = array();
		$result['login'] = 1;
		
		echo json_encode($result);
		
	}
    
}